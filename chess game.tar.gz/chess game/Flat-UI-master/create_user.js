var app = angular.module("userDetailApp", ["firebase","hSweetAlert"]);


app.controller("userCtrl",  function($scope,$window,sweet,$firebaseArray ,$firebaseObject) {
    
  
    
    var ref = new Firebase("https://chess-kumuda.firebaseio.com/");
    var userRef = ref.child("users");
    var usernameCheckQuery;
    var usernameCheckArray;
    var userDetailArray ; 
    var obj;
    
    $scope.emailSigntext = "";
    $scope.usernameSigntext = "";
    $scope.passwordSigntext = "";
    $scope.confirmPasswordSigntext = "";
    $scope.username = "";
    $scope.email = "";
   
    
    $scope.loginEmailtext = "";
    $scope.loginPasswordtext = "";
    $scope.loginEmail = "";
    
    $scope.resetEmailtext = "";
    $scope.resetEmail = "";
         
    /*$scope.register = function() {
        if($scope.password != $scope.confirmPassword) {
            alert("Password donot match");
            return;
        }
        
        
           
    }*/
    
   /* $scope.login = function() {
        
        
        
        if($scope.loginEmail && $scope.loginPassword) {
            
        }
        else {
            alert("fill all the details");   
        }
    } */
    
  /*  $scope.onExit = function() {
      return ('bye bye');
    };

   $window.onbeforeunload =  $scope.onExit; */
    
    
    $scope.login = function(loginEmail,loginPassword) {
        var entered = 0;
        if(loginEmail === undefined || loginEmail.length === 0) {
            entered = 1;
            $scope.loginEmailtext = "enter the email address";
            $scope.loginEmail = "";
        }else if(loginEmail.indexOf("@")  === -1 || loginEmail.indexOf(".")  === -1){
            entered = 1;      
            $scope.loginEmailtext = "invalid email";
            $scope.loginEmail = "";
        }
        if(loginPassword === undefined || loginPassword.length === 0) {
            entered = 1; 
            $scope.loginPasswordtext = "enter the password";   
            $scope.loginPassword = "";
        }
        if(entered === 0) {
            
                ref.authWithPassword({
                    email    : $scope.loginEmail,
                    password : $scope.loginPassword
                }, function(error, authData) {
                    if (error) {
                    //alert(error.message);    
                    console.log("Login Failed!", error);
                    $scope.$apply(function () {
                        if(error.message.indexOf("password") > -1) {
                            $scope.loginPasswordtext = error.message;
                            $scope.loginPassword = "";
                            $scope.loginEmailtext = "";
                        }
                        else {
                            $scope.loginEmailtext = error.message;   
                            $scope.loginEmail = "";                        
                            $scope.loginPasswordtext = "";
                            $scope.loginPassword = "";
                        }
                    });
                        
                } else {
                    
                   // localStorage.setItem('userDetail',JSON.stringify(authData));
                   // var user  = JSON.parse(localStorage.getItem('userDetail'));
                    var user;
                    var userObj ; 
                    var query = userRef.orderByChild("uid").equalTo(authData.uid);
                    userObj = $firebaseArray(query);
                    
                  
                    userObj.$loaded().then(function(messages) {
                        
                        
                        
                        userObj[0].status = "online";
                        localStorage.setItem('userDetail',JSON.stringify(userObj[0]));
                        user = JSON.parse(localStorage.getItem('userDetail'));
                        userObj.$save(userObj[0]);
                        
                        $window.location.href = 'showFriends.html';
                       
                    });
                    
                    
                    console.log("Authenticated successfully with payload:",authData);
                    
                }
                });
           
        }
    }
    
    $scope.resetPassword = function(resetEmail) {
        var entered = 0;
        if(resetEmail === undefined || resetEmail.length === 0) {
            entered = 1;  
            $scope.resetEmailtext = "enter the email address";
            $scope.resetEmail = "";
            
        }else if(resetEmail.indexOf("@") === -1 || resetEmail.indexOf(".") === -1){
            entered = 1;      
            $scope.resetEmailtext = "invalid email";
            $scope.resetEmail = "";
        }
        if(entered === 0) {
            ref.resetPassword({
                email : $scope.resetEmail
            }, function(error) {
            if (error === null) {
                //alert("Password reset email sent successfully");
                var text = "is sent to "+resetEmail;
                sweet.show({
                    title: "Reset password email",
                    text: text,
                    type: 'success',
                    showConfirmButton: true
                });
                console.log("Password reset email sent successfully");
            } else {
                //alert(error.message);
                console.log("Error sending password reset email:", error);
                $scope.$apply(function () {
                    $scope.resetEmailtext = error.message;
                    $scope.resetEmail = "";
                });
            }
            });
        }
    }
    
    $scope.setresetEmailtext = function() {
        $scope.resetEmailtext = "";
    }
    
    $scope.setloginEmailtext = function(loginEmail) {
        $scope.loginEmailtext = "";
    }
    
    $scope.setloginPasswordtext = function(loginPassword) {
        $scope.loginPasswordtext = "";   
    }
    
    
    
    
    $scope.setemailSigntext = function(email) {
        $scope.emailSigntext = "";   
    }
    
    $scope.setusernameSigntext = function(username) {
        if( username.length < 4 ) {
            $scope.usernameSigntext = "username lenght should be atleat 4"; 
        }else {
            $scope.usernameSigntext = "";
        }
    }
    
    $scope.setpasswordSigntext = function(password , confirmPassword) {
        if(password.length < 7) {
            $scope.passwordSigntext = "password lenght should be atleast 7";
        }
        else {
            $scope.passwordSigntext = "";
        }
        if(password != confirmPassword)  {
            $scope.confirmPasswordSigntext = "did not match with password ";   
        }
        else{
            $scope.confirmPasswordSigntext = "";
        }
    }
    
    $scope.setconfirmPasswordSigntext = function(password , confirmPassword) {
        if(password != confirmPassword)  {
            $scope.confirmPasswordSigntext = "did not match with password ";   
        }
        else{
            $scope.confirmPasswordSigntext = "";
        }
    }
    
    $scope.register = function(email ,username, password , confirmPassword) {
        var entered = 0;
        if(email === undefined || email.length === 0) {
            entered = 1;
            $scope.emailSigntext = "did not enter the email address";   
            $scope.email = "";
        }else if(email.indexOf("@") === -1 || email.indexOf(".") === -1) {
            entered = 1;
            $scope.emailSigntext = "invalid email address";   
            $scope.email = "";
        }
        if(username === undefined || username.length === 0) {
            entered = 1;
            $scope.username = "";
            $scope.usernameSigntext = "did not enter the username";   
        }
        else if(username.length < 4) {
            entered = 1;
            $scope.username = "";
            $scope.usernameSigntext = "username lenght should be atleat 4";  
        }
        if(password === undefined || password.length === 0) {
            entered = 1;
            $scope.password = "";
            $scope.passwordSigntext = "did not enter the password";
            $scope.confirmPassword = "";
        }
        if(confirmPassword === undefined || confirmPassword.length === 0) {
            entered = 1;
            $scope.confirmPassword = "";
            $scope.confirmPasswordSigntext = "did not enter the confirm password";
        }
        if(entered === 0) {
            if(password.length < 7) {
                $scope.passwordSigntext = "password lenght should be atleast 7";
                $scope.password = "";
                $scope.confirmPassword = "";
                
            }
            else if(password != confirmPassword)  {
                $scope.confirmPasswordSigntext = "did not match with password ";   
                $scope.confirmPassword = ""; 
            }
            else {
                usernameCheckQuery = userRef.orderByChild("username").equalTo($scope.username);
                usernameCheckArray = $firebaseArray(usernameCheckQuery);
                
                usernameCheckArray.$loaded().then(function(messages) {
                    console.log("usernameCheckArray : ",usernameCheckArray);
                    if(usernameCheckArray.length != 0) {
                       // alert("User with this username is already present");
                        $scope.$apply(function () {
                            $scope.username = "";
                            $scope.usernameSigntext = "User with this username is already present"; 
                        });
                    }
                    else {   
                            ref.createUser({
                            email : $scope.email,
                            password : $scope.password
                    }, function(error, userData) {
                            if(error) {
                               // alert(error.message);    
                                console.log(error.message);
                                $scope.$apply(function () {
                                    $scope.emailSigntext = error.message;   
                                    $scope.email = "";
                                });
                            } else {
                                var push_uid = userData.uid;
                                obj = {
                                        "uid"       :  push_uid  ,
                                        "email"     :  $scope.email,
                                        "username"  :  $scope.username,
                                        "status"    :  "online" 
                 
                                };
                                userDetailArray  = $firebaseArray(userRef);
                                userDetailArray.$add(obj);
                        
                                localStorage.setItem('userDetail',JSON.stringify(obj));
                                console.log(JSON.parse(localStorage.getItem('userDetail')));  
                        
                                $window.location.href = 'showFriends.html';
                          
                        
                
                            }
                    });
              
                }
                       
            });
                
            }
            
        }
        
    }
    
   
});


app.controller("friendCtrl", function($scope,$window,sweet, $firebaseArray, $firebaseObject) {
   
    
    $scope.$on('$locationChangeStart', function( event ) {
    var answer = confirm("Are you sure you want to leave this page?")
    if (!answer) {
        event.preventDefault();
    }
    });
    
    var ref = new Firebase("https://chess-kumuda.firebaseio.com/");
    var userRef = ref.child("users");
    var requestRef = ref.child("requests");
    var acceptRef = ref.child("acceptedRequests");
    var gamesRef = ref.child("games");
    var requestArray;
    var responseArray;

    var length_of_array = 0;
    var length_of_responsearray = 0;
    
    var user = JSON.parse(localStorage.getItem('userDetail'));
    console.log(user);
    
    localStorage.setItem('gameid',0);
    
    var userObj ; 
    var gameObj = {};
    
    var query =  userRef.orderByChild("status").equalTo("online");
    var query1 = userRef.orderByChild("uid").equalTo(user.uid);
    var query2 = requestRef.orderByChild("recieverUid").equalTo(user.uid);
    var query3 = requestRef.orderByChild("senderUid").equalTo(user.uid);
    
    userObj = $firebaseArray(query1);
    userObj.$loaded().then(function(messages) {   
        
                    userObj[0].status = "online";
                    userObj.$save(userObj[0]);
    });
                        
    userRef.on("value", function(snapshot) {
         $scope.availableUsers = $firebaseArray(query);    
     });
    
    requestRef.on("value", function(snapshot) {
                
       requestArray = $firebaseArray(query2);             
       requestArray.$loaded().then(function(messages) {
                        
                        length_of_array = requestArray.length;
                        var obj,i;
                        for(i = 0 ; i < length_of_array ; i++ ) {
                                obj  = requestArray[i];
                            if( obj.status === "sent") {
                                
                            localStorage.setItem('gameid',obj.senderUid);
                            localStorage.setItem('senderid',obj.senderUid);
                            localStorage.setItem('recieverid',obj.recieverUid);    
                        
                                
                            sweet.show({
                                title: 'Want to play',
                                text: 'with ' + obj.senderName,
                                imageUrl: 'http://icons.iconarchive.com/icons/osullivanluke/orb-os-x/512/Chess-icon.png',
                                showCancelButton: true,
                                confirmButtonColor: '#DD6B55',
                                confirmButtonText: 'Yes, play!',
                                closeOnConfirm: false,
                                closeOnCancel: false
                            }, function(isConfirm) {
                                if (isConfirm) {
                                   
                              
                                    obj.status = "accepted";
                                    requestArray.$save( obj );
                                    localStorage.setItem('opponentName',obj.senderName); 
                                   sweet.show({
                                                title: 'You Accepted',
                                                text: 'the request',
                                                type: 'success',
                                                timer: 2000,
                                                showConfirmButton: false
                                    });
                                    
                                    userObj = $firebaseArray(query1);
                                     
                                    userObj.$loaded().then(function(messages) {   
                
                                        userObj[0].status = "gaming";
                                        userObj.$save(userObj[0]);
                                           
                                        
                                    
                                         console.log("entered1"); 
                                        var gameid = obj.senderUid;
                                        gameObj[gameid] = {
                                            "white": obj.senderUid,
                                            "black": obj.recieverUid,
                                            "whiteName" : obj.senderName,
                                            "blackName" : obj.recieverName,
                                            "movesFrom": 'A3' , 
                                            "movesTo": 'A3',
                                            "turn" : "white",
                                            "winner" : ""
                                        };                                                                                             
                                        gamesRef.set(gameObj);  
                                        console.log("entered2"); 
                                        console.log("entered2 ",obj.senderUid ); 
                                        
                                        var thisgamesRef = gamesRef.child(obj.senderUid);
                                        
                                        thisgamesRef.on("value", function(snapshot) {
                                              if(snapshot.val() != null) {
                                                    alert('you are going to play game');
                                                    $window.location.href = 'game.html';
                                              }
                                           
                                        });            
                                  
                                        
                                       
                                    });
                                    
                                    
                                }else{
                                             
                                    console.log("desicion false");
                                    obj.status = "denied";
                                    requestArray.$save( obj );
                                    sweet.show({
                                        title: 'Cancelled Request',
                                        text: '',
                                        type: 'error',
                                        timer: 2000,
                                        showConfirmButton: false
                                    });
                                    
                                }
                            });
                                
                            }
                                   
                        }
                       
        });
        
        responseArray = $firebaseArray(query3);    
        responseArray.$loaded().then(function(messages) {
                        
                        length_of_responsearray = responseArray.length;
                        var obj,i;
                        var text;
                        
                        for(i = 0 ; i < length_of_responsearray ; i++ ) {
                                obj =  responseArray[i];
                                text = 'by ' + obj.recieverName;
                                if( obj.status === "accepted") {
                                    
                                    
                                    localStorage.setItem('gameid',user.uid);
                                    localStorage.setItem('senderid',obj.senderUid);
                                    localStorage.setItem('recieverid',obj.recieverUid);  
                                    localStorage.setItem('opponentName',obj.recieverName);  
                                    
                                    responseArray.$remove(obj);
                                    
                                    sweet.show({
                                        title: 'Accepted Request!',
                                        text: text,
                                        type: 'success',
                                        timer: 2000,
                                        showConfirmButton: false
                                    });
                                    
                                    userObj = $firebaseArray(query1);
                                     
                                    userObj.$loaded().then(function(messages) {   
                                        console.log("entered1"); 
                                        userObj[0].status = "gaming";
                                        userObj.$save(userObj[0]);
                                     
                                        console.log("entered2"); 
                                        console.log("entered2 ",user.uid ); 
                                        var thisgamesRef = gamesRef.child(user.uid);
                                        
                                        thisgamesRef.on("value", function(snapshot) {
                                            if(snapshot.val() != null) {
                                                   alert('you are going to play game');
                                                    $window.location.href = 'game.html';
                                            }
                                           
                                        });  
                                       
                                        
                                         
                                    });
                                    
                                    
                                    
                                }else if(obj.status === "denied") {
                                    sweet.show('Denied Request', text, 'error'); 
                                    responseArray.$remove(obj);
                                }
                        }
                       
        });
        
        
        
        
        
        
     });
    
    
    $scope.sendRequest = function(opponent) {
         requestObj = {
            "senderUid"   :  user.uid,
            "senderName"  :  user.username,
            "recieverUid" :  opponent.uid,
            "recieverName":  opponent.username,
             "status"     :  "sent"
         };
        
        requestArray.$add(requestObj);
        alert("your request is sent to "+opponent.username);
        
    }
    
    $scope.dontShowItself = function(object) {
        console.log("passed : ",object);
        if(object.uid === user.uid)
            return false;
        else
            return true;
    }
    
    $scope.logOut =  function() {
        
        if(user != null) {
            userObj = $firebaseArray(query1);
                                     
            userObj.$loaded().then(function(messages) {   
                
                userObj[0].status = "offline";
                userObj.$save(userObj[0]);
                
                
                $window.location.href = 'login.html';
                
            });
                
            localStorage.removeItem('userDetail');
            user = null;
            
            console.log("successfully logged out");
        }else {
            console.log("already removed");   
        }
        
    }
    
});

app.controller("gameCtrl", function($scope, $firebaseArray,sweet,$timeout, $window, $firebaseObject) {
    
   
    var mainref = new Firebase("https://chess-kumuda.firebaseio.com/");
    var userRef = mainref.child("users");
    
    var user = JSON.parse(localStorage.getItem('userDetail'));
    
    var thisGame = JSON.parse(localStorage.getItem('gameObj')); 
    console.log("thisGame : ",thisGame);
    var gameid = thisGame.white;
    
    localStorage.setItem('gameid',thisGame.white);
    localStorage.setItem('senderid',thisGame.white);
    localStorage.setItem('recieverid',thisGame.black);
    
    if(thisGame.white === user.uid) {
              
        localStorage.setItem('opponentName',thisGame.blackName);      
        localStorage.setItem('opponentid',thisGame.black);
        
    }else {
        
        localStorage.setItem('opponentName',thisGame.whiteName);      
        localStorage.setItem('opponentid',thisGame.white);
        console.log("request id : ", localStorage.getItem('requestId'));
        mainref.child("requests").child(localStorage.getItem('requestId')).set(null);
    }
    
    $scope.profileName = localStorage.getItem('opponentName'); //opponent name
    console.log("opponentName : ",localStorage.getItem('opponentName'));
    console.log("gameid : ",localStorage.getItem('gameid'));
    console.log("opponentid : ",localStorage.getItem('opponentid'));
    
                                    
    
    var other,white , black , turn ,movesFrom,movesTo ;
    var correctGame = 0;
    var query1 = userRef.orderByChild("uid").equalTo(user.uid);
    var oppQuery = userRef.orderByChild("uid").equalTo(localStorage.getItem('opponentid'));
    var userObj;
    
    var friendsRef = mainref.child("friends");
    var pushedidRef = new Firebase("https://chess-kumuda.firebaseio.com/pushedid");
    
    var thisfriendsRef = friendsRef.child(user.uid);
    var thispushedidRef = pushedidRef.child(user.uid);
    var IamSender;
    var idObj;
    
     userObj = $firebaseArray(query1);
     userObj.$loaded().then(function(messages) {   
                    console.log("entered",userObj[0]);
                    console.log(" userObj id  : ",userObj[0].$id);
                    userObj[0].status = localStorage.getItem('opponentid');
                    userObj.$save(userObj[0]);
                    console.log(userObj[0]);
                 
    });
    
    
    
    thispushedidRef.on("value", function(snapshot) {
        console.log(snapshot.val());
        idObj = snapshot.val();
    });
    
    
    setStatusInFriend = function() {
           var array1 = $firebaseArray(thisfriendsRef);
           var object = {
                            uid : user.uid,
                            username : user.username,
                            status : "gaming"
                     };
           array1.$loaded().then(function(messages) { 
                var i;
                for(i = 0 ; i < array1.length ; i++)  {
                   
                    var element = array1[i];
                    console.log(element.username+" :  ",idObj[element.uid]); 
                    var elementRef = friendsRef.child(element.uid);
                    var thisRef = elementRef.child(idObj[element.uid]);
                    thisRef.set(object);
                    
                    
                }
           });
    }
    setStatusInFriend();
    
    
    $scope.onExit = function() {
      //return ('bye bye');
     if(correctGame === 1) {
         var address = "https://chess-kumuda.firebaseio.com/games/" +gameid
         console.log("address ",address);
         var ref = new Firebase(address);
         ref.set(null);
     }
        
    };

   $window.onbeforeunload =  $scope.onExit;
    
    
    
    
    
    
    
    
    
    console.log("entered main part");
    
    var oppObj = $firebaseArray( oppQuery );
    var opponentId ;
     oppObj.$loaded().then(function(messages) {   
                console.log("opponent object  : ",oppObj[0]);
                   opponentId =  oppObj[0].$id;
                 console.log("opponentId at userRef : ",opponentId);
                
                var oppId = userRef.child(opponentId);
    oppId.on("value", function(snapshot) {
        if(snapshot.val().status != "gaming" &&  snapshot.val().status != "online" && snapshot.val().status != "offline") {
            
            if( user.uid   === localStorage.getItem('senderid')) {
                correctGame = 1;
                IamSender = "white";
                if(snapshot.val().status === user.uid) {
                    var gameid = user.uid;
                    var gameObj;
                    gameObj = {
                        "white": user.uid,
                        "black": localStorage.getItem('recieverid') ,
                        "whiteName" : user.username,
                        "blackName" : localStorage.getItem('opponentName'),
                        "movesFrom": 'A3' , 
                        "movesTo": 'A3',
                        "turn" : "white",
                        "winner" : ""
                    };                                                                                               
                                     
                    var gamesRef = mainref.child("games").child(user.uid);        
                    gamesRef.set(gameObj);
                    
                    console.log("entered senderid");
                    var requestRef2 = mainref.child("requests");
                    var query3 = requestRef2.orderByChild("senderUid").equalTo(user.uid);
                    var reqsenderArray = $firebaseArray(query3);
                    var j;
                    reqsenderArray.$loaded().then(function(messages) { 
                            console.log("entered senderid senderArray");
                            for(j = 0 ; j < reqsenderArray.length ; j++) {
                                reqsenderArray.$remove(reqsenderArray[j]);

                            }
                    });
        
                    var query2 = requestRef2.orderByChild("recieverUid").equalTo(user.uid);
                    var reqrecieverArray = $firebaseArray(query2);
                    reqrecieverArray.$loaded().then(function(messages) { 
                        console.log("entered senderid recieve array");    
                        var k;
                        for(k = 0 ; k < reqrecieverArray.length ; k++) {
                            reqrecieverArray[k].status = "denied";
                            reqrecieverArray.$save(reqrecieverArray[k]);
                        }
            
            
                    });
                    
                }else {
                    console.log("entered else of sender");
                      $window.location.href = 'showFriends.html';      
                }
                
            }
            else if( user.uid   === localStorage.getItem('recieverid') ) {
                IamSender = "black";
                if(snapshot.val().status === user.uid) {
                    correctGame = 1;
                    console.log("entered recieverid");
                    var requestRef = mainref.child("requests");
                    var query2 = requestRef.orderByChild("recieverUid").equalTo(user.uid);
                    var reqrecieverArray = $firebaseArray(query2);
                    reqrecieverArray.$loaded().then(function(messages) { 
                        console.log("entered recieverid recieve array");    
                        var k;
                        for(k = 0 ; k < reqrecieverArray.length ; k++) {
                            reqrecieverArray[k].status = "denied";
                            reqrecieverArray.$save(reqrecieverArray[k]);
                        }
            
            
                    });
        
                    var query3 = requestRef.orderByChild("senderUid").equalTo(user.uid);
                    var reqsenderArray = $firebaseArray(query3);
                    var j;
                    reqsenderArray.$loaded().then(function(messages) { 
                        console.log("entered recieverid sender array");
                        for(j = 0 ; j < reqsenderArray.length ; j++) {
                            reqsenderArray.$remove(reqsenderArray[j]);

                        }
                    });
                    
                    
                }else {   
                        console.log("entered else of reciever");
                             $window.location.href = 'showFriends.html';            
                }
                
            }
            
        }else if(snapshot.val().status === "online") {
            sweet.show({
                title: 'Sorry',
                text: 'the request is cancelled',
                type: 'error',
                timer: 5000,
                showConfirmButton: false
            });
            $scope.QuitGame(); 
            
        }
    });
         
         
    });
    
    
    
    
    sweet.show({
        title: 'Loading',
        text: 'game starts in 3sec',
        type: 'success',
        timer: 5000,
        showConfirmButton: false
    });
    
   /* $scope.onExit = function() {
            return ('bye bye');
        };

    $window.onbeforeunload =  $scope.onExit;*/
    
  
    if(gameid != 0) {
        var address = "https://chess-kumuda.firebaseio.com/games/" +gameid
        console.log("address ",address);
        var ref = new Firebase(address);
        
     
        var firstmove , secondmove;
        
        
        ref.on("value", function(snapshot) {
           if(snapshot.val() != null) {
            white = snapshot.val().white;
            black = snapshot.val().black;
            turn  = snapshot.val().turn;
            
            
            var syncObject = $firebaseObject(ref);
            syncObject.$bindTo($scope, "widget");
            
            if(user.uid === white)
                $scope.whiteOrblack = "white";
            else    
                $scope.whiteOrblack = "black";
            
            if(snapshot.val() != null && snapshot.val().winner != "") {                           
              
                
                      
                if(snapshot.val() != null && snapshot.val().winner === "draw") {
                        //alert("Match is draw");   
                        sweet.show({
                            title: 'Match is draw',
                            text: '',
                            type: 'error',
                            timer: 5000,
                            showConfirmButton: false
                        });
                }else if(snapshot.val() != null) {
                      //  alert(snapshot.val().winner+" has won the match");
                    if(IamSender === snapshot.val().winner) {
                        sweet.show({
                            title: snapshot.val().winner,
                            text: 'has won the match',
                            type: 'success',
                            timer: 5000,
                            showConfirmButton: false
                        });
                    }else {
                       
                        sweet.show({
                            title: snapshot.val().winner,
                            text: 'has won the match',
                            type: 'error',
                            timer: 5000,
                            showConfirmButton: false
                        });
                        
                        
                        
                    }
                }  
                ref.set(null);
                
            }
            
            if(turn === "white")
                other = "black";
            else
                other = "white";
           }else {
                
                 $timeout(callAtTimeout, 3000);
                    
                
           }
        }, function (errorObject) {
        console.log("The read failed: " + errorObject.code);
        });
        
        callAtTimeout = function() {
            $window.location.href = 'showFriends.html';
        }
        
        $scope.winnerDeclared = function() {
               ref.update({ winner : $scope.winner});
        }
        
        
        $scope.update = function(move,variable_1) 
        {
        if( (user.uid === white && turn === "white") || (user.uid === black && turn === "black"))               
        {
                console.log("entered update"+move+"   "+variable_1);
           	if(variable_1 === '1') 
           	{
           	console.log("1");
           		firstmove = move;
           	}
           	else
           	{
           	console.log("2");
           		secondmove = move;
           		ref.update({ movesFrom: firstmove, movesTo: secondmove , turn: other });
           	}
                
            }
            else {
                console.log("it is not your turn");
              
            }
        }
        
        $scope.winner = function() {
            if($scope.whiteOrblack === "white") {
                ref.update({ winner : "white"});
            }
            else
                ref.update({ winner : "black"});
        }
        
        $scope.draw = function() {
            ref.update({ winner : "draw"});
        }
        
        $scope.QuitGame =  function() {
            
            ref.set(null);
            console.log("successfully logged out");
            
        }
        
        
      
        
        
        
    }
        
});

app.controller("showfriendCtrl", function($scope,$window,sweet, $firebaseArray, $firebaseObject) {
    var ref = new Firebase("https://chess-kumuda.firebaseio.com/");
    var userRef = ref.child("users");
    var friendsRef = ref.child("friends");
    var friendRequsetRef = ref.child("friendrequests");
    var notificationRef = ref.child("notifications");
    var pushedidRef = new Firebase("https://chess-kumuda.firebaseio.com/pushedid");
    var deniedReqNotifyRef = ref.child("deniedRequests");
    
    $scope.result = $firebaseArray(userRef);   
    var user = JSON.parse(localStorage.getItem('userDetail')); 
    $scope.profile = user.username;
    $scope.userInf = user;
    
    $scope.OldPasswordtext = "";
    $scope.NewPasswordtext = "";
    $scope.ConfirmPasswordtext = "";
    $scope.NewEmailtext = "";
    $scope.OldEmailtext = "";
    $scope.Passwordtext = "";
    $scope.OldEmail = "";
    $scope.NewEmail = "";
    
    $scope.remark = "";
    $scope.remark2 = "";
    
    var thisfriendsRef = friendsRef.child(user.uid);
    var thisfriendsReqRef = friendRequsetRef.child(user.uid);
    var thisnotificationRef = notificationRef.child(user.uid);
    var thispushedidRef = pushedidRef.child(user.uid);
    var thisdeniedReqNotifyRef = deniedReqNotifyRef.child(user.uid);
    var query1 = userRef.orderByChild("uid").equalTo(user.uid);
    
    
    var requestRef = ref.child("requests");
    var acceptRef = ref.child("acceptedRequests");
    var gamesRef = ref.child("games");
    var requestArray;
    var responseArray;

    var length_of_array = 0;
    var length_of_responsearray = 0;
    

    localStorage.setItem('gameid',0);
    localStorage.setItem('senderid',0);
    localStorage.setItem('recieverid',0); 
    localStorage.setItem('opponentid',0);
    localStorage.setItem('gameObj',null); 
    localStorage.setItem('requestId',0);
    
    var gameObj = {};
    
    var query =  userRef.orderByChild("status").equalTo("online");
    var query2 = requestRef.orderByChild("recieverUid").equalTo(user.uid);
    var query3 = requestRef.orderByChild("senderUid").equalTo(user.uid);
    
    
    $scope.onExit = function() {
      //return ('bye bye');
        
                
              var array1 = $firebaseArray(thisfriendsRef);
              var object = {
                            uid : user.uid,
                            username : user.username,
                            status : "offline"
                     };
              array1.$loaded().then(function(messages) { 
                var i;
                 
                    for(i = 0 ; i < array1.length ; i++)  {
                   
                        var element = array1[i];
                        console.log(element.username+" :  ",idObj[element.uid]); 
                        var elementRef = friendsRef.child(element.uid);
                        var thisRef = elementRef.child(idObj[element.uid]);
                        thisRef.set(object);
                    
                    }
                
             });   
                
                
           
    };

   $window.onbeforeunload =  $scope.onExit;
    
    
    var gamesRef2 = ref.child("games").child(user.uid);        
    gamesRef2.set(null);
    
    var userObj = $firebaseArray(query1);
    userObj.$loaded().then(function(messages) {   
        
                    userObj[0].status = "online";
                    userObj.$save(userObj[0]);
    });
    
    var friendsArray;
    var friendsReqArray;
    var notifyArray;
    var query5,query6;
    var idObj;
    console.log("user : ",user);
    
    thispushedidRef.on("value", function(snapshot) {
        console.log(snapshot.val());
        idObj = snapshot.val();
    });
    
    
    thisfriendsRef.on("value", function(snapshot) {
        $scope.friendsList = $firebaseArray(thisfriendsRef);
        var query7 = thisfriendsRef.orderByChild("status").equalTo("online");
        $scope.friendsOnline =  $firebaseArray(query7);
    });
    
    thisfriendsReqRef.on("value", function(snapshot) {
        $scope.presentRequests = $firebaseArray(thisfriendsReqRef); 
        $scope.presentRequests.$loaded().then(function(messages) {   
            $scope.reqCount = $scope.presentRequests.length;
        });
    });
    
    thisnotificationRef.on("value", function(snapshot) {
        $scope.notifications = $firebaseArray(thisnotificationRef); 
        $scope.notifications.$loaded().then(function(messages) {   
            $scope.notifyCount = $scope.notifications.length;
        });
    });
    
    thisdeniedReqNotifyRef.on("value", function(snapshot) {
        $scope.denynotifications = $firebaseArray(thisdeniedReqNotifyRef); 
        $scope.denynotifications.$loaded().then(function(messages) {   
            $scope.deniedNotifyCount = $scope.denynotifications.length;
        });
    });
    
    setStatusInFriend = function() {
           var array1 = $firebaseArray(thisfriendsRef);
           var object = {
                            uid : user.uid,
                            username : user.username,
                            status : "online"
                     };
           array1.$loaded().then(function(messages) { 
                var i;
                for(i = 0 ; i < array1.length ; i++)  {
                   
                    var element = array1[i];
                    console.log(element.username+" :  ",idObj[element.uid]); 
                    var elementRef = friendsRef.child(element.uid);
                    var thisRef = elementRef.child(idObj[element.uid]);
                    thisRef.set(object);
                    
                    
                }
           });
    }
    setStatusInFriend();
    
    $scope.addFriend = function(friend) {
    
        if(friend.uid != user.uid) {   
            var query7 = friendRequsetRef.child(friend.uid);
            query6 = query7.orderByChild("senderUid").equalTo(user.uid);
            friendsReqArray = $firebaseArray(query6);  
            
            friendsReqArray.$loaded().then(function(messages) {   
                console.log(friendsReqArray);
                if(friendsReqArray.length === 0) {
                    query5 = thisfriendsRef.orderByChild("uid").equalTo(friend.uid);
            
                    friendsArray = $firebaseArray(query5);   
        
                    friendsArray.$loaded().then(function(messages) {   
             
                        if(friendsArray.length === 0)   {
                            var obj = {
                                    senderName :   user.username,
                                    senderUid  :   user.uid,
                                    recieverName : friend.username,
                                    recieverUid :   friend.uid
                        
                            };
                    
                            query6 = friendRequsetRef.child(friend.uid);
                            console.log(friend);
                            friendsReqArray = $firebaseArray(query6);  
                    
                    
                            friendsReqArray.$add(obj);
                            var msg = "friend request is sent to "+friend.username;
                            var  notifyObj = {
                                            text: msg
                                            };
                            $scope.notifications.$add(notifyObj);    
                        }
                        else {
                            var msg = friend.username+" is already your friend";
                            var  notifyObj = {
                                            text: msg
                                         };
                            $scope.notifications.$add(notifyObj);     
                        }
                    });
                }
                else {
                    var msg = "friend request has been already sent to "+friend.username;
                            var  notifyObj = {
                                            text: msg
                                             };
                    $scope.notifications.$add(notifyObj);  
                }
            });
        }
        $scope.friendName = "";
    }
    
    
    $scope.AcceptedReq = function(request) {
        
        $scope.presentRequests.$remove(request);
        var query9 = userRef.orderByChild("uid").equalTo(request.senderUid);
        var friendObj = $firebaseArray(query9); 
        
        var query15 = thisfriendsRef.orderByChild("uid").equalTo(request.senderUid);
        var check = $firebaseArray(query15);
        check.$loaded().then(function(messages) { 
            if(check.length === 0) {
            friendObj.$loaded().then(function(messages) { 
                //friendsArray = $firebaseArray(thisfriendsRef); 
            //friendsArray.$add(friendObj[0]);
           
                check.$add(friendObj[0]).then(function(ref) {
                var id = ref.key();
                
                console.log("added record with id " + id);
                
                var idRef = new Firebase("https://chess-kumuda.firebaseio.com/pushedid");
                var idRef1 = idRef.child(request.senderUid);
                var idRef2 = idRef1.child(user.uid);
            
                idRef2.set(id);
                
                check.$indexFor(id); // returns location in the array
                });
        
            
            
            
            });
            }
        });    
        
        var query10 = userRef.orderByChild("uid").equalTo(user.uid);
        var friendObj1 = $firebaseArray(query10); 
        
        var query7 = friendsRef.child(request.senderUid).orderByChild("uid").equalTo(user.uid);
        var friendsArray2 = $firebaseArray(query7);
        
        friendsArray2.$loaded().then(function(messages) { 
            if(friendsArray2.length === 0) {
            friendObj1.$loaded().then(function(messages) { 
            
            friendsArray2.$add(friendObj1[0]).then(function(ref) {
                var id = ref.key();
                
                console.log("added record with id " + id);
                
                var idRef = new Firebase("https://chess-kumuda.firebaseio.com/pushedid");
                var idRef1 = idRef.child(user.uid);
                var idRef2 = idRef1.child(request.senderUid);
            
                idRef2.set(id);
                
                friendsArray2.$indexFor(id); // returns location in the array
            });
            
            
            });
            }
        
    });
        
        var msg = "you and "+request.senderName + " are now friends";
                            var  notifyObj = {
                                            text: msg
                                             };
        $scope.notifications.$add(notifyObj);  
        
        var query8 = notificationRef.child(request.senderUid)
        notifyArray = $firebaseArray(query8); 
        msg = user.username + " accepted your friend request";
        notifyObj = {
                        text: msg
                    };
        notifyArray.$add(notifyObj);
            
    }
    
    $scope.RejectedReq = function(request) {
        $scope.presentRequests.$remove(request);
        
        var msg = "you rejected "+request.senderName;
                            var  notifyObj = {
                                            text: msg
                                             };
        $scope.notifications.$add(notifyObj);  
        
        var query8 = notificationRef.child(request.senderUid)
        notifyArray = $firebaseArray(query8); 
        msg = user.username + " rejected your friend request";
        notifyObj = {
                        text: msg
                    };
        notifyArray.$add(notifyObj);
    }
    
    $scope.removeNotify = function(thisNotification){
        $scope.notifications.$remove(thisNotification);  
    }
    
    $scope.removeDenyNotify = function(denynotification){
        $scope.denynotifications.$remove(denynotification);  
    }
    
    
    requestRef.on("value", function(snapshot) {
                
       requestArray = $firebaseArray(query2);             
       requestArray.$loaded().then(function(messages) {
                        var array4 = requestArray;
                        length_of_array = requestArray.length;
                        var obj,i,j;
                        for(i = 0 ; i < length_of_array ; i++ ) {
                                obj  = requestArray[i];
                            console.log("the i value outside : ",i);
                            if( obj.status === "sent") {
                                
                               
                            
                                
                            sweet.show({
                                title: 'Want to play',
                                text: 'with ' + obj.senderName,
                                imageUrl: 'http://icons.iconarchive.com/icons/osullivanluke/orb-os-x/512/Chess-icon.png',
                                showCancelButton: true,
                                confirmButtonColor: '#DD6B55',
                                confirmButtonText: 'Yes, play!',
                                closeOnConfirm: false,
                                closeOnCancel: true
                            }, function(isConfirm) {
                                if (isConfirm) {
                                   
                                    var acceptedReqObj = obj;
                                    
                                 /*   localStorage.setItem('gameid',obj.senderUid);
                                    localStorage.setItem('senderid',obj.senderUid);
                                    localStorage.setItem('recieverid',obj.recieverUid); 
                                    localStorage.setItem('opponentName',obj.senderName);
                                    localStorage.setItem('opponentid',obj.senderUid); */
                                    
                                    obj.status = "accepted";
                                    requestArray.$save( obj );
                                    console.log("saved accepted");
                                    
                                    
                                    
                                   sweet.show({
                                                title: 'You Accepted',
                                                text: 'the request',
                                                type: 'success',
                                                timer: 2000,
                                                showConfirmButton: false
                                    });
                                    
                                    
                                        
                                    
                                         console.log("entered1"); 
                                        var gameid = obj.senderUid;
                                        gameObj[gameid] = {
                                            "white": obj.senderUid,
                                            "black": obj.recieverUid,
                                            "whiteName" : obj.senderName,
                                            "blackName" : obj.recieverName,
                                            "movesFrom": 'A3' , 
                                            "movesTo": 'A3',
                                            "turn" : "white",
                                            "winner" : ""
                                        };                                                                                               
                              var checkOpponent = $firebaseArray(userRef.orderByChild("uid").equalTo(acceptedReqObj.senderUid));
                                    
                                    
                                 checkOpponent.$loaded().then(function(messages) {
                                     console.log("checkOpponent : ",checkOpponent[0]);
                                    if(checkOpponent[0].status === "online") {       
                                    var thisgamesRef = gamesRef.child(obj.senderUid);    
                                    thisgamesRef.on("value", function(snapshot) {
                                            if(snapshot.val() === null) {
                                          // localStorage.setItem('gameObj',gameObj);  
                                                    gamesRef.set(gameObj);
                                                    
                                                   // $window.location.href = 'game.html';
                                              }
                                            else {
                                                if(snapshot.val().black != user.uid)  {
                                                    
                                                sweet.show({
                                                    title: 'You Accepted Request',
                                                    text: 'but your friend is busy',
                                                    type: 'error',
                                                    timer: 1000,
                                                    showConfirmButton: false
                                                });
                                                }else {
                             
                                                    
                                                    userObj = $firebaseArray(query1);
                                                    userObj.$loaded().then(function(messages) {   
        
                                                        userObj[0].status = "gaming";
                                                        userObj.$save(userObj[0]);
                                                        
                             localStorage.setItem('gameObj',JSON.stringify(snapshot.val()));
                            localStorage.setItem('requestId',obj.$id);
                                                        $window.location.href = 'game.html';
                                                    });
                                                    
                                                    
                                                }
                                            }
                                           
                                        });
                                    }else {
                                        sweet.show({
                                                    title: 'You Accepted Request',
                                                    text: 'but your friend is busy',
                                                    type: 'error',
                                                    timer: 1000,
                                                    showConfirmButton: false
                                                });
                                    }
                                 });
                                    
                              
                                    
                                }else{
                                             
                                    console.log("desicion false");
                                    obj.status = "denied";
                                    requestArray.$save( obj );
                                   
                                    
                                }
                            });
                                
                            }
                                   
                        }
                       
        });
        
        var thisgamesRef = gamesRef.child(user.uid);
                                        
        thisgamesRef.on("value", function(snapshot) {
        if(snapshot.val() != null) {
                                            
            localStorage.setItem('gameObj',JSON.stringify(snapshot.val())); 
                                    
                                            
            sweet.show({
                title: 'Accepted Request by!',
                text: snapshot.val().blackName,
                type: 'success',
                timer: 2000,
                showConfirmButton: false
            });
            userObj = $firebaseArray(query1);
            userObj.$loaded().then(function(messages) {   
        
                    userObj[0].status = "gaming";
                    userObj.$save(userObj[0]);
                                                
                    $window.location.href = 'game.html';
            });
                                        
            }
                                           
            });  
                                    
        
        
        responseArray = $firebaseArray(query3);   
        responseArray.$loaded().then(function(messages) {
                        var array4 = responseArray;
                        length_of_responsearray = responseArray.length;
                        var obj,i,j;
                        var text;
                        
                        for(i = 0 ; i < length_of_responsearray ; i++ ) {
                                obj =  responseArray[i];
                                text = 'by ' + obj.recieverName;
                                if( obj.status === "accepted") {
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                }else if(obj.status === "denied") {
                                    //var text2 = obj.recieverName;
                                    //sweet.show(text2, 'is busy', 'error'); 
                                    responseArray.$remove(obj);
                                    
                                    var msg = obj.recieverName + " is busy , could not accept game request ";
                                    var  notifyObj = {
                                            text: msg,
                                            
                                             };
                                   
                                    $scope.denynotifications.$add(notifyObj);  
                                }
                        }
                       
        });
        
        
        
        
        
        
     });
    
    $scope.sendRequest = function(opponent) {
         requestObj = {
            "senderUid"   :  user.uid,
            "senderName"  :  user.username,
            "recieverUid" :  opponent.uid,
            "recieverName":  opponent.username,
             "status"     :  "sent"
         };
        
        requestArray.$add(requestObj);
        alert("your request is sent to "+opponent.username);
        
    }
    
    $scope.setOldPasswordtext = function(OldPassword) {
        
        $scope.OldPasswordtext = "";
        $scope.remark = ""
    }
    
    $scope.setNewPasswordtext = function(NewPassword,ConfirmPassword) {
        console.log("entered setNewPasswordtext");
        console.log(NewPassword);
       if(NewPassword.length < 7) {  
            $scope.NewPasswordtext = "password lenght should be minimum 7"; 
        }else {
            $scope.NewPasswordtext = "";   
        }
        
        if(NewPassword != ConfirmPassword) {
            $scope.ConfirmPasswordtext = "did not match with New Password";
        }else {
             $scope.ConfirmPasswordtext = "";
        }
        $scope.remark = ""
    }
    
    $scope.setConfirmPasswordtext = function(ConfirmPassword) {
        console.log("entered setConfirmPasswordtext");
        if($scope.NewPassword != ConfirmPassword) {
            $scope.ConfirmPasswordtext = "did not match with New Password";
        }else {
             $scope.ConfirmPasswordtext = "";
        }
        $scope.remark = ""
    }
    
    $scope.setPasswordtext = function(Password) {
            console.log("entered setPasswordtext");
            $scope.Passwordtext = "";
            $scope.remark2 = "";
    }
    
    $scope.setOldEmailtext = function(OldEmail) {
            console.log("entered setOldEmailtext");
            $scope.OldEmailtext = "";
            $scope.remark2 = "";
    }
    
    $scope.setNewEmailtext = function(NewEmail) {
            console.log("entered setNewEmailtext");
            $scope.NewEmailtext = "";
            $scope.remark2 = "";
    }
    
    $scope.UpdateEmail = function(OldEmail,NewEmail,Password) {
        console.log(OldEmail);
        console.log(NewEmail);
        console.log(Password);
        var entered = 0;
        if(OldEmail === undefined || OldEmail.length === 0 ) {
                entered = 1;  
                $scope.OldEmail = "";
                $scope.OldEmailtext = "enter the Old Email Address";
                $scope.remark2 = "";
        }
        if(NewEmail === undefined || NewEmail.length === 0 ) {
                entered = 1;  
                $scope.NewEmail = "";
                $scope.NewEmailtext = "enter the New Email Address";
                $scope.remark2 = "";
        }
        if(Password === undefined || Password.length === 0) {
            entered = 1;  
            $scope.Password = "";
            $scope.Passwordtext = "enter the Password";
            $scope.remark2 = "";
        }
        if(entered === 0) {
            
            if(user.email != OldEmail) {
                 $scope.OldEmail = "";
                 $scope.OldEmailtext = "entered wrong email address";
            }
            else {
                
                
                ref.changeEmail({
                    oldEmail : user.email,
                    newEmail : NewEmail,
                    password : Password
                }, function(error) {
                if (error === null) {
                    
                    user.email = NewEmail;
                    userObj = $firebaseArray(query1);
                                     
                    userObj.$loaded().then(function(messages) {   
                
                        userObj[0].email = NewEmail;
                        userObj.$save(userObj[0]);
                        localStorage.setItem('userDetail',JSON.stringify(userObj[0]));
                    });
                    
                    $scope.$apply(function () {
                       $scope.NewEmail = "";
                       $scope.OldEmail = "";
                       $scope.Password = "";
                       $scope.OldEmailtext = "";
                       $scope.NewEmailtext = "";
                       $scope.Passwordtext = "";
                       $scope.remark2 = "email address is changed";
                    });
                    
                    console.log("Email changed successfully");
                } else {
                    console.log("Error changing email:", error);
                    
                    $scope.$apply(function () {
                        if(error.code === "INVALID_PASSWORD") {
                            $scope.Password = "";
                            $scope.Passwordtext = "entered wrong password";
                        }
                        else if(error.code === "EMAIL_TAKEN") {
                            $scope.NewEmail = "";
                            $scope.NewEmailtext = "another user is using that email id ";
                        }
                        else if(error.code === "INVALID_EMAIL"){
                            $scope.NewEmail = "";
                            $scope.NewEmailtext = "invalid email address";
                        }else {
                            $scope.NewEmail = "";
                            $scope.NewEmailtext = error.code;
                        }
                            
                       
                       $scope.remark2 = "";
                    });
                    
                    }
                });
                
            }
            
            
        }
        
    }
    
    $scope.UpdatePassword = function(newPassword ,ConfirmPassword ,OldPassword ) {
        console.log(newPassword);
        console.log(ConfirmPassword);
        console.log(OldPassword);
        var entered = 0;
        if(newPassword === undefined || newPassword.length === 0  ) {
                   entered = 1;
                   $scope.NewPasswordtext = "enter the new password";
                   $scope.NewPassword = "";
                   $scope.ConfirmPassword = ""; 
                   $scope.remark = ""
        }
        if(ConfirmPassword === undefined || ConfirmPassword.length === 0 ) {
                   entered = 1;
                   $scope.ConfirmPasswordtext = "enter the confirm password"; 
                   $scope.remark = ""
        }
        if(OldPassword === undefined ||  OldPassword.length === 0 ) {
                   entered = 1;
                   $scope.OldPasswordtext = "enter the old password";     
                   $scope.remark = ""
        }
        if(entered === 0) {
            if(newPassword.length < 7) {
                $scope.NewPasswordtext = "password lenght should be minimum 7";   
                $scope.ConfirmPasswordtext = "";
                $scope.OldPasswordtext = "";
            
                $scope.NewPassword = "";
                $scope.ConfirmPassword = "";
            }else if(newPassword != ConfirmPassword) {
                $scope.NewPasswordtext = "";   
                $scope.ConfirmPasswordtext = "did not match with New Password";
                $scope.OldPasswordtext = "";
            
                $scope.ConfirmPassword = "";
            
            }else {
                
            
                ref.changePassword({
                    email       : user.email,
                    oldPassword : OldPassword,
                    newPassword : newPassword
                }, function(error) {
                if (error === null) {
                
                
                    
                    $scope.$apply(function () {
                        $scope.NewPasswordtext = "";   
                        $scope.ConfirmPasswordtext = "";
                        $scope.OldPasswordtext = "";
                
                        $scope.OldPassword = "";
                        $scope.NewPassword = "";
                        $scope.ConfirmPassword = "";
                        $scope.remark = "password is  changed";
                    });
                    console.log("Password changed successfully");
                } else {
              /*  $scope.NewPasswordtext = "";   
                $scope.ConfirmPasswordtext = "";
                $scope.OldPasswordtext = "The specified password is incorrect";
                
                $scope.OldPassword = ""; */
                
                    
                    
                    $scope.$apply(function () {
                        
                        $scope.NewPasswordtext = "";   
                        $scope.ConfirmPasswordtext = "";
                        $scope.OldPasswordtext = "The specified password is incorrect";
                
                        $scope.OldPassword = "";
                        $scope.remark = "";
                    });
                    console.log("$scope.remark:", "jkl,");
                    console.log("Error changing password:", error);
                }
                });
            
            }
        }
        
    }
    
    
    $scope.logOut =  function() {
        
        if(user != null) {
            
            user.status = "offline";
            userObj = $firebaseArray(query1);
                                     
            userObj.$loaded().then(function(messages) {   
                
                
                userObj[0].status = "offline";
                userObj.$save(userObj[0]);
                
                
              var array1 = $firebaseArray(thisfriendsRef);
              var object = {
                            uid : user.uid,
                            username : user.username,
                            status : "offline"
                     };
              array1.$loaded().then(function(messages) { 
                var i;
                if(array1.length === 0)  {
                    $window.location.href = 'login.html';
                }
                else {  
                    for(i = 0 ; i < array1.length ; i++)  {
                   
                        var element = array1[i];
                        console.log(element.username+" :  ",idObj[element.uid]); 
                        var elementRef = friendsRef.child(element.uid);
                        var thisRef = elementRef.child(idObj[element.uid]);
                        thisRef.set(object);
                    
                        if(i === (array1.length - 1)) {
                            $window.location.href = 'login.html';
                        }
                    }
                }
             });   
                
                
            });
                
            localStorage.removeItem('userDetail');
          
            
            console.log("successfully logged out");
        }else {
            console.log("already removed");   
        }
        
    }
    
    
});




app.controller("chatCtrl", function($scope, $firebaseArray, $firebaseObject) {
    var ref = new Firebase("https://chess-kumuda.firebaseio.com/");
    var chatRef = ref.child("chat");
    $scope.classButton = "btn btn-block btn-lg btn-inverse";
    var gameid = "abc";
    var user = JSON.parse(localStorage.getItem('userDetail'));
    var movesRef = chatRef.child(gameid);
    var movesArrayRef =  movesRef.child("moves");
    var playerWhite = "";
    console.log("testing : ",user.uid);
    var id1 = "-1";
    if(user != null){
         id1 = user.uid;
         console.log("hii : ",id1);   
    }
    
    var id2 = "88f381d4-a7c6-4c75-9ff3-ecd486e61742";
    if(id1 === "88f381d4-a7c6-4c75-9ff3-ecd486e61742") {
        id2 = "f3ca12c8-777a-4d06-8b9d-4644d8f85e4a";
    }
    
    
    movesArrayRef.on("value", function(snapshot) {
       
        $scope.messages = $firebaseArray(movesArrayRef);
       
        
        $scope.messages.$loaded().then(function(messages) {
            
            console.log($scope.messages);
             if((JSON.parse(localStorage.getItem('userDetail'))).uid === playerWhite) {
                
               if( (($scope.messages).length)%2 === 0  ) {
                    $scope.classButton = "btn btn-block btn-lg btn-inverse";
               }else {
                    $scope.classButton = "btn btn-block btn-lg btn-default disabled";
               }
         }else  {
               if( (($scope.messages).length)%2 === 0  ) {
                    $scope.classButton = "btn btn-block btn-lg btn-default disabled";
               }else {
                    $scope.classButton = "btn btn-block btn-lg btn-inverse";
               }
         }
            
        });

        
        
       
        
    }, function (errorObject) {
        console.log("The read failed: " + errorObject.code);
    });
    
     $scope.changeClass = function(){
       
        $scope.messages.$add(
             $scope.message
        );
             
    };

    $scope.logOut = function() {
        
        if(user != null) {
            console.log("Authenticated successfully with payload:",user.uid);
            localStorage.removeItem('userDetail');
            user = null;
        }else {
            console.log("already removed");   
        }
        
    }
    
    $scope.createGame = function() {
        console.log(id1);   
        console.log(id2);   
        
        var gameObj = {};
        
        gameObj[gameid] = {
            "white": id1,
            "black": id2,
            "moves": []    
        };
        
        chatRef.set(gameObj);
        playerWhite = id1;
         
        if((JSON.parse(localStorage.getItem('userDetail'))).uid === playerWhite) {
               
                    $scope.classButton = "btn btn-block btn-lg btn-inverse";
              
         }else  {
               
                    $scope.classButton = "btn btn-block btn-lg btn-default disabled";
               
         }
        
    }
    
});
